import java.io.IOException;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

public class APLHITUNGNILAI extends MIDlet implements CommandListener {

    private StringItem ip, nilaiakhirmhs, itemip1, itemip2, itemip3,
            nii, itemNA, itemJSKS, itembobot, itemtes, itemtes2;
    int p, jsks, na, j2, j1, tt, ss, jssks, jsbobot, nbobot;
    private TextField nilaiip, NAMAMK, NILAIMK, JUMLAHSKS, JSKS, JMK, nama, nim,
            nilaiquis, nilaimidtes, nilaitugas, nilaiuas;
    private TextField[] f;
    private TextField[] g;
    private TextField[] h;
    private Command cmdKeluar = new Command("Keluar", Command.EXIT, 0);
    private Command cmdttg = new Command("Tentang", Command.SCREEN, 0);
    private Command cmdLihat = new Command("Lihat", Command.SCREEN, 1);
    private Command cmdhitung = new Command("Hitung", Command.SCREEN, 1);
    private Command cmdkembali = new Command("Kembali", Command.BACK, 0);
    Display display;
    private ImageItem gbr, gbr2, logo, logo2, logo3,logopnl;
    private Image img, img2, ilogo, ilogo2, ilogo3, ilogopnl;;
    private Form form;
    private TextField userName, password;
    private Command cancel, CMDMASUK, login, cmdOk;
    MMenu menu = new MMenu(this);
    Form formapl = new Form("");
    Form formtentang = new Form("");
    Form form1 = new Form("Perhitungan Nilai IP");
    Form form2 = new Form("masukkan nilai dan sks");
    Form formnilai = new Form("Hitung Nilai Akhir");
    Form formNILAIAKHIR = new Form("Nilai Akhir Anda");
    Form form3 = new Form("Nilai IP Anda");
    private String hsl1, hsl2, Hrf;
    private StringItem itemtes3, itemtes1, ket1, ttg;

    public void startApp() {

        display = Display.getDisplay(this);

        try {
            img = Image.createImage("/gambar/login.png");
        } catch (IOException ex) {
            ex.printStackTrace();  }
        
        try {
            img2 = Image.createImage("/gambar/L3.png");
        } catch (IOException ex) {
            ex.printStackTrace();   }

        try {
            ilogo = Image.createImage("/gambar/icon.png");
        } catch (IOException ex) {
            ex.printStackTrace();  }      
        try {
            ilogo2 = Image.createImage("/gambar/icon.png");
        } catch (IOException ex) {
            ex.printStackTrace();  }
        
        try {
            ilogo3 = Image.createImage("/gambar/icon.png");
        } catch (IOException ex) {
            ex.printStackTrace(); }
        
        try {
            ilogopnl = Image.createImage("/gambar/createddd.png");
        } catch (IOException ex) {
            ex.printStackTrace();  }
        
        gbr = new ImageItem("Silakan Login" + "\n", img, ImageItem.LAYOUT_CENTER, null);
        gbr2 = new ImageItem("", img2, ImageItem.LAYOUT_CENTER, null);
        logo = new ImageItem("", ilogo, ImageItem.LAYOUT_CENTER, null);
        logo2 = new ImageItem("", ilogo2, ImageItem.LAYOUT_CENTER, null);
        logo3 = new ImageItem("", ilogo3, ImageItem.LAYOUT_CENTER, null);
        logopnl = new ImageItem("", ilogopnl, ImageItem.LAYOUT_CENTER, null);
        CMDMASUK = new Command("Masuk", Command.BACK, 1);
        formapl.append(gbr2);
        formapl.addCommand(CMDMASUK);
        formapl.setCommandListener(this);
        display.setCurrent(formapl);

        userName = new TextField("Login_ID :", "", 7, TextField.ANY);
        password = new TextField("Password:", "", 7, TextField.PASSWORD);
        form = new Form("Login");
        cancel = new Command("Batal", Command.CANCEL, 1);
        login = new Command("Login", Command.OK, 2);
        form.append(gbr);
        form.append(userName);
        form.append(password);
        form.addCommand(cancel);
        form.addCommand(login);
        form.setCommandListener(this);


        nama = new TextField("Nama Anda  ", null, 20, TextField.ANY);
        nim = new TextField("Nim Anda   ", null, 10, TextField.NUMERIC);
        nilaitugas = new TextField("Nilai Tugas ", null, 4, TextField.NUMERIC);
        nilaiquis = new TextField("Nilai Quis  ", null, 4, TextField.NUMERIC);
        nilaimidtes = new TextField("Nilai Midtes", null, 4, TextField.NUMERIC);
        nilaiuas = new TextField("Nilai Uas   ", null, 4, TextField.NUMERIC);

        formnilai.append(logo);
        formnilai.addCommand(cmdLihat);
        formnilai.addCommand(cmdkembali);
        formnilai.append(nama);
        formnilai.append(nim);
        formnilai.append(nilaitugas);
        formnilai.append(nilaiquis);
        formnilai.append(nilaimidtes);
        formnilai.append(nilaiuas);

        JMK = new TextField("\nMasukkan jumlah MK", null, 4, TextField.ANY);
        ttg = new StringItem("Aplikasi Perhitungan Nilai Mahasiswa" + "\nDibuat Oleh :"
           + "\nAnita\nTMJ 2.2\nNIM : 1490343029\nEmail : anitatmj01@gmail.com", null);
        formapl.addCommand(cmdttg);
        formtentang.addCommand(cmdKeluar);
        formtentang.addCommand(cmdkembali);
        formtentang.setCommandListener(this);
        formtentang.append(logopnl);
        formtentang.append(ttg);

        cmdOk = new Command("Ok", Command.SCREEN, 3);
        form1.append(logo2);
        form1.append(JMK);
        form1.addCommand(cmdOk);
        form1.addCommand(cmdkembali);
        form1.setCommandListener(this);
    }
    public void pauseApp() {
    }
    public void destroyApp(boolean unconditional) {
    }
    void Hitung1() {
        formnilai.setCommandListener(this);
        display.setCurrent(formnilai);
    }
    void Hitung2() {

        form1.setCommandListener(this);
        display.setCurrent(form1);
    }
    void Keluar() {

        destroyApp(true);
        notifyDestroyed();
    }
    void cekinput(String name, String pass) {
        if (name.equals("anita") && pass.equals("12345")) {
            MMenu m = new MMenu(this);
            m.setFullScreenMode(true);
            Display.getDisplay(this).setCurrent(m);

        } else {
            cobalagi();
        }
    }

    void cobalagi() {
        Alert error = new Alert("Login Salah", "Silakan coba lagi", null, 
                AlertType.ERROR);
        error.setTimeout(Alert.FOREVER);
        userName.setString("");
        password.setString("");
        display.setCurrent(error, form);
    }

    public void commandAction(Command c, Displayable d) {
        if (c == cmdttg) {
            display.setCurrent(formtentang);
        } else if (c == CMDMASUK) {
            display.setCurrent(form);

        } else if (c == login) {
            cekinput(userName.getString(), password.getString());

        } else if (c == cancel) {
            destroyApp(true);
            notifyDestroyed();

        } else if (c == cmdOk) {

            int i, t = 0, n, y, l;
            p = Integer.parseInt(JMK.getString());
            int b;

            g = new TextField[p];
            f = new TextField[p];
            h = new TextField[p];

            for (y = 0; y <= g.length; y++) {

                g[y] = new TextField("Nama    MK", null, 15, TextField.ANY);
                f[y] = new TextField("Nilai   MK", null, 4, TextField.ANY);
                h[y] = new TextField("Jumlah SKS", null, 4, TextField.NUMERIC);

                form2.append(g[y]);
                form2.append(f[y]);
                form2.append(h[y]);
                form2.addCommand(cmdKeluar);
                form2.addCommand(cmdhitung);
                form2.setCommandListener(this);
                display.setCurrent(form2);

            }
        } else if (c == cmdhitung) {

            form3.append(logo3);
            ket1 = new StringItem("Nama MK      NILAI     SKS      N X K", null);
            form3.append(ket1);

            try {
                for (int dd = 0; dd <= g.length || dd <= f.length || dd <= h.length; dd++) {

                    jsks = Integer.parseInt(h[dd].getString());

                    if (f[dd].getString().equals("A")) {
                        na = 4;
                        Hrf = "A";
                    } else if (f[dd].getString().equals("B")) {
                        na = 3;
                        Hrf = "B";
                    } else if (f[dd].getString().equals("C")) {
                        na = 2;
                        Hrf = "C";
                    } else if (f[dd].getString().equals("D")) {
                        na = 1;
                        Hrf = "D";
                    } else if (f[dd].getString().equals("E")) {
                        na = 0;
                        Hrf = "E";
                    } else if (f[dd].getString().equals("")) {
                        itemNA = new StringItem("Nilai Belum diisi", null);
                        form3.append(itemNA);
                        System.out.print("kosong");
                        Hrf = "-";
                    } else {
                        System.out.println("salah");
                    }

                    hsl1 = g[dd].getString();
                    jsks = Integer.parseInt(h[dd].getString());
                    nbobot = jsks * na;
                    jsbobot += nbobot;
                    jssks += jsks;

                    itemip3 = new StringItem("" + hsl1 + "            " + Hrf + " "
                            + "         " + jsks + "             " + nbobot, null);

                    form3.append(itemip3);


                }
            } catch (Exception e) {
                e.printStackTrace();
            }


            float nip;
            nip = (float) jsbobot / (float) jssks;

            itemtes1 = new StringItem("-----------------------------------------------------\n"
                    + "                                  " + jssks + "             " + jsbobot, null);

            itemtes3 = new StringItem("\nIP = Total Bobot / Total SKS\n    = " + jsbobot + " "
                    + ": " + jssks + "\n    = " + nip, null);

            form3.append(itemtes1);
            form3.append(itemtes3);
            form3.addCommand(cmdKeluar);
            form3.addCommand(cmdkembali);
            form3.setCommandListener(this);
            display.setCurrent(form3);

        } else if (c == cmdLihat) {

            float nt, nq, nm, nuas;
            String huruf = null, a1, a2;
            a1 = nama.getString();
            a2 = nim.getString();
            float aa = 0.15f, bb = 0.2f, cc = 0.25f, dd = 0.4f, nakhir;

            nt = Float.parseFloat(nilaitugas.getString());
            nq = Float.parseFloat(nilaiquis.getString());
            nm = Float.parseFloat(nilaimidtes.getString());
            nuas = Float.parseFloat(nilaiuas.getString());

            nakhir = (nt * aa) + (nq * bb) + (nm * cc) + (nuas * dd);

            if (nakhir >= 81 && nakhir <= 100) {
                huruf = "A";
            } else if (nakhir >= 66 && nakhir <= 80.99) {
                huruf = "B";
            } else if (nakhir >= 56 && nakhir <= 65.99) {
                huruf = "C";
            } else if (nakhir >= 41 && nakhir <= 55.99) {
                huruf = "D";
            } else if (nakhir >= 0 && nakhir <= 40.99) {
                huruf = "E";
            } else {
                System.out.println("Error");
            }
            nilaiakhirmhs = new StringItem("\nNama : " + a1 + "\nNIM : " + a2 + "\nNilai Akhir : "+nakhir+"\nGrade : "+ huruf, null);
            formNILAIAKHIR.setCommandListener(this);
            formNILAIAKHIR.append(logo3);
            formNILAIAKHIR.append(nilaiakhirmhs);
            formNILAIAKHIR.addCommand(cmdKeluar);
            formNILAIAKHIR.addCommand(cmdkembali);
            display.setCurrent(formNILAIAKHIR);

        } else if (c == cmdkembali) {
            display.setCurrent(formapl);
        } else {

            destroyApp(true);
            notifyDestroyed();

        }


    }
}
