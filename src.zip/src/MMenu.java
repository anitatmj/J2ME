
import java.io.IOException;
import javax.microedition.lcdui.Canvas;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

class MMenu extends Canvas {

    private APLHITUNGNILAI midletUT;
    private int y, x;
    public int index;

    private Image hitungNA1,hitungIP1, keluarOff,hnilai;
    private Image hitungNA2, hitungIP2, keluarOn,hnilai2;

    public MMenu(APLHITUNGNILAI midlet) {
        midletUT = midlet;
        
        setFullScreenMode(false);
        y = getHeight();
        x = getWidth();

        try {
            
            hnilai = Image.createImage("/gambar/hn.png");
            hitungNA1 = Image.createImage("/gambar/B3.png");
            hitungIP1 = Image.createImage("/gambar/B2.png");
            keluarOff = Image.createImage("/gambar/B1.png"); 
      
       
      hnilai2 = Image.createImage("/gambar/hn.png");
            hitungNA2 = Image.createImage("/gambar/B3.png");
           hitungIP2= Image.createImage("/gambar/B2.png");
            keluarOn = Image.createImage("/gambar/B1.png");
            
           
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

   

    


    protected void paint(Graphics g) {
        g.setColor(62, 96, 240);
        g.fillRect(0, 0, x, y); //mengisi kotak dengan warna
        g.drawImage(hnilai, x / 2, y / 5, Graphics.HCENTER | Graphics.VCENTER);
        g.drawImage(hitungNA1, x / 2, y / 5+50, Graphics.HCENTER | Graphics.VCENTER);
        g.drawImage(hitungIP1, x / 2, y / 5 + 100, Graphics.HCENTER | Graphics.VCENTER);
        g.drawImage(keluarOff, x / 2, y / 5+ 150, Graphics.HCENTER | Graphics.VCENTER);
      
       
        switch (index) {
             case 0:
                //g.drawImage(hnilai2, x / 2, y / 4- 2, Graphics.HCENTER | Graphics.VCENTER);
                 break;
            case 1:
                g.drawImage(hitungNA2, x / 2, y / 5 +45, Graphics.HCENTER | Graphics.VCENTER);
                break;
            case 2:
                g.drawImage(hitungIP2, x / 2, y / 5+ 95, Graphics.HCENTER | Graphics.VCENTER);
                break;
            case 3:
                g.drawImage(keluarOn, x / 2, y / 5 + 145, Graphics.HCENTER | Graphics.VCENTER);
                break;
 
            default:
        }
        repaint();
    }

    public void keyPressed(int tekan) {

        if (getGameAction(tekan) == DOWN) {
            index++;
            if (index > 4) {
                index = 0;
            }
        }
        if (getGameAction(tekan) == UP) {
            index--;
            if (index < 0) {
                index = 4;
            }
        }
        if (getGameAction(tekan) == FIRE) {

            switch (index) {
                case 0:
                    
                case 1:
                    midletUT.Hitung1();
                    break;
                    
                case 2:
                    midletUT.Hitung2();
                    break;
                   
                     case 3:
                    
                          midletUT.Keluar();
                    break;
                    
           
                default:

            }
        }

    }
}
